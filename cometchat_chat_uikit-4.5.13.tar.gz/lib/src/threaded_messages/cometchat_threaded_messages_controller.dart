import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../cometchat_chat_uikit.dart';

///[CometChatThreadedMessageController] is the view model for [CometChatThreadedMessages]
///it contains all the business logic involved in changing the state of the UI of [CometChatThreadedMessages]
class CometChatThreadedMessageController extends GetxController
    with
        CometChatMessageEventListener,
        MessageListener,
        CometChatGroupEventListener,
        CometChatUIEventListener{
  //--------------------Constructor-----------------------
  CometChatThreadedMessageController(this.parentMessage, this.loggedInUser,
      {this.parentMessageContentView}) {
    if (parentMessage.sender!.uid == loggedInUser.uid) {
      if (parentMessage.receiver is Group) {
        group = (parentMessage.receiver as Group);
      } else {
        user = (parentMessage.receiver as User);
      }
    } else {
      if (parentMessage.receiver is Group) {
        group = (parentMessage.receiver as Group);
      } else {
        user = parentMessage.sender!;
      }
    }

    tag = "tag$counter";
    replyCount = parentMessage.replyCount;
  }

  //-------------------------Variable Declaration-----------------------------
  ///[parentMessageContentView] content view for parent message
  final Widget? parentMessageContentView;
  late BaseMessage parentMessage;
  User? user;
  Group? group;
  User loggedInUser;
  late String _dateString;
  late String _uiMessageListener;
  late String _uiGroupListener;
  late String _uiEventListener;
  CometChatMessageComposerController? composerState;
  static int counter = 0;
  late String tag;
  late int replyCount;

  final GlobalKey messageComposerKey = GlobalKey();

  Widget? composerPlaceHolder;

  double _baseComposerHeight = 0.0; // Tracks the natural composer height
  double _panelHeight = 0;
  bool _panelVisible = false;

  void updatePanelVisibility(bool visible, double height) {
    _panelVisible = visible;
    _panelHeight = height;
    getComposerPlaceHolder(); // Recalculate placeholder height
    update();
  }

  void getComposerPlaceHolder() {
    final context = messageComposerKey.currentContext;
    if (context == null || !context.mounted) {
      composerPlaceHolder = const SizedBox();
      return;
    }

    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!context.mounted) return;

      final renderBox = context.findRenderObject() as RenderBox?;
      if (renderBox == null) {
        composerPlaceHolder = SizedBox(height: _baseComposerHeight);
        return;
      }

      // Update base height only when panel is closed
      if (!_panelVisible) {
        _baseComposerHeight = renderBox.size.height;
      }

      final totalHeight = _panelVisible
          ? _baseComposerHeight + _panelHeight
          : _baseComposerHeight;

      composerPlaceHolder = SizedBox(
        height: totalHeight.clamp(0, double.infinity), // Ensure positive height
        key: ValueKey('${_panelVisible}_$totalHeight'),
      );
      update();
    });
  }

  //-------------------------LifeCycle Methods-----------------------------
  @override
  void onInit() {
    super.onInit();
    counter++;
    _dateString = DateTime.now().millisecondsSinceEpoch.toString();
    _uiMessageListener = "${_dateString}UI_message_listener";
    _uiGroupListener = "${_dateString}UI_group_listener";
    _uiEventListener = "${_dateString}UI_event_listener";
    CometChatMessageEvents.addMessagesListener(_uiMessageListener, this);
    CometChatGroupEvents.addGroupsListener(_uiGroupListener, this);
    CometChatUIEvents.addUiListener(_uiEventListener, this);
  }

  @override
  void onClose() {
    CometChatMessageEvents.removeMessagesListener(_uiMessageListener);
    CometChatGroupEvents.removeGroupsListener(_uiGroupListener);
    CometChatUIEvents.removeUiListener(_uiEventListener);
    super.onClose();
  }

  //------------------------SDK Message Event Listeners------------------------------
  @override
  void onMessageDeleted(BaseMessage message) {
    if (message.id == parentMessage.id) {
      parentMessage = message;
      update();
    }
  }

  @override
  void onMessageEdited(BaseMessage message) {
    if (message.id == parentMessage.id) {
      parentMessage = message;
      update();
    }
  }

  @override
  void onTextMessageReceived(TextMessage textMessage) {
    if (textMessage.parentMessageId == parentMessage.id) {
      replyCount++;
      update();
    }
  }

  @override
  void onMediaMessageReceived(MediaMessage mediaMessage) {
    if (mediaMessage.parentMessageId == parentMessage.id) {
      replyCount++;
      update();
    }
  }

  @override
  void onCustomMessageReceived(CustomMessage customMessage) {
    if (customMessage.parentMessageId == parentMessage.id) {
      replyCount++;
      update();
    }
  }

  @override
  void onSchedulerMessageReceived(SchedulerMessage schedulerMessage) {
    if (schedulerMessage.parentMessageId == parentMessage.id) {
      replyCount++;
      update();
    }
  }

  //------------------------UI Message Event Listeners------------------------------
  @override
  ccMessageSent(BaseMessage message, MessageStatus messageStatus) {
    if (messageStatus == MessageStatus.sent) {
      replyCount++;
      update();
    }
  }

  @override
  void ccMessageDeleted(BaseMessage message, EventStatus messageStatus) {
    if (message.id == parentMessage.id) {
      update();
    }
  }

  @override
  void ccMessageEdited(BaseMessage message, MessageEditStatus status) {
    if (message.id == parentMessage.id && status == MessageEditStatus.success) {
      update();
    }
  }

  @override
  void showPanel(Map<String, dynamic>? id, CustomUIPosition uiPosition,
      WidgetBuilder child) {
    if (uiPosition == CustomUIPosition.composerBottom) {
      double height = _parsePanelHeight(id?["sticker_height"]);
      updatePanelVisibility(true, height);
    }
  }

  @override
  void hidePanel(Map<String, dynamic>? id, CustomUIPosition uiPosition) {
    if (uiPosition == CustomUIPosition.composerBottom) {
      double height = _parsePanelHeight(id?["sticker_height"]);
      updatePanelVisibility(false, height);
    }
  }

  double _parsePanelHeight(dynamic stickerHeight) {
    try {
      if (stickerHeight is int) return stickerHeight.toDouble();
      if (stickerHeight is double) return stickerHeight;
      if (stickerHeight is String) return double.tryParse(stickerHeight) ?? 0;
      return 0.0;
    } catch (e) {
      debugPrint("Error parsing panel height: $e");
      return 0.0;
    }
  }
}
