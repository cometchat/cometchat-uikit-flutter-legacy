import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../cometchat_chat_uikit.dart';
import '../message_composer/live_reaction_animation.dart';

///[CometChatMessagesController] is the view model for [CometChatMessages]
///it contains all the business logic involved in changing the state of the UI of [CometChatMessages]
class CometChatMessagesController extends GetxController
    with
        CometChatMessageEventListener,
        MessageListener,
        CometChatGroupEventListener,
        CometChatUserEventListener,
        CometChatUIEventListener
{
  late String _dateString;
  late String _uiMessageListener;
  late String _uiGroupListener;
  late String _uiUserListener;
  late String _uiEventListener;
  bool isOverlayOpen = false;
  List<Widget> liveAnimationList = [];
  CometChatMessageComposerController? composerState;
  CometChatDetailsController? detailsState;
  User? user;
  Group? group;
  User? loggedInUser;
  late BuildContext context;
  static int counter = 0;
  late String tag;

  ///[threadedMessagesConfiguration] sets configuration properties for [CometChatThreadedMessages]
  final ThreadedMessagesConfiguration? threadedMessagesConfiguration;

  CometChatMessagesController(
      {this.user, this.group, this.threadedMessagesConfiguration}) {
    _dateString = DateTime.now().millisecondsSinceEpoch.toString();
    _uiMessageListener = "${_dateString}UI_message_listener";
    _uiGroupListener = "${_dateString}UI_group_listener";
    _uiUserListener = "${_dateString}UI_user_listener";
    _uiEventListener = "${_dateString}UI_event_listener";
    tag = "tag$counter";
    counter++;
  }

  final GlobalKey messageComposerKey = GlobalKey();

  double _baseComposerHeight = 0.0; // Tracks the natural composer height
  double _panelHeight = 0;
  bool _panelVisible = false;

  void updatePanelVisibility(bool visible, double height) {
    _panelVisible = visible;
    _panelHeight = height;
    getComposerPlaceHolder(); // Recalculate placeholder height
    update();
  }

  Widget? composerPlaceHolder;

  void getComposerPlaceHolder() {
    final context = messageComposerKey.currentContext;
    if (context == null || !context.mounted) {
      composerPlaceHolder = const SizedBox();
      return;
    }

    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!context.mounted) return;

      final renderBox = context.findRenderObject() as RenderBox?;
      if (renderBox == null) {
        composerPlaceHolder = SizedBox(height: _baseComposerHeight);
        return;
      }

      // Update base height only when panel is closed
      if (!_panelVisible) {
        _baseComposerHeight = renderBox.size.height;
      }

      final totalHeight = _panelVisible
          ? _baseComposerHeight + _panelHeight
          : _baseComposerHeight;

      composerPlaceHolder = SizedBox(
        height: totalHeight.clamp(0, double.infinity), // Ensure positive height
        key: ValueKey('${_panelVisible}_$totalHeight'),
      );
      update();
    });
  }

  @override
  void onInit() {
    super.onInit();
    CometChatMessageEvents.addMessagesListener(_uiMessageListener, this);
    CometChatGroupEvents.addGroupsListener(_uiGroupListener, this);
    CometChatUserEvents.addUsersListener(_uiUserListener, this);
    CometChatUIEvents.addUiListener(_uiEventListener, this);
    _initializeLoggedInUser();
  }

  @override
  void onClose() {
    CometChatMessageEvents.removeMessagesListener(_uiMessageListener);
    CometChatGroupEvents.removeGroupsListener(_uiGroupListener);
    CometChatUserEvents.removeUsersListener(_uiUserListener);
    CometChatUIEvents.removeUiListener(_uiEventListener);
    super.onClose();
  }

  //-----MessageComposerListener methods-----

  @override
  void onTransientMessageReceived(TransientMessage message) async {
    if ((message.receiverType == ReceiverTypeConstants.user &&
            message.receiverId == loggedInUser?.uid &&
            (message.sender != null &&
                user != null &&
                message.sender?.uid == user?.uid)) ||
        (message.receiverType == ReceiverTypeConstants.group &&
            group != null &&
            message.receiverId == group?.guid)) {
      if (message.data["type"] == "live_reaction") {
        isOverlayOpen = true;
        String reaction = message.data["reaction"];
        _addAnimations(reaction);
      }
    }
  }

  @override
  void ccLiveReaction(String reaction) async {
    isOverlayOpen = true;
    _addAnimations(reaction);
  }

  //----------User Event Listeners--------------
  @override
  void ccUserBlocked(User user) {
    if (this.user?.uid == user.uid) {
      this.user?.blockedByMe = true;
    }
  }

  @override
  void ccUserUnblocked(User user) {
    if (this.user?.uid == user.uid) {
      this.user?.blockedByMe = false;
    }
  }

  _initializeLoggedInUser() async {
    loggedInUser = await CometChat.getLoggedInUser();
  }

  _addAnimations(String reaction) async {
    //Counter to add no of live reactions
    int counter = 2;
    for (int i = 0; i < counter; i++) {
      _addAnimation(reaction);
      await Future.delayed(const Duration(milliseconds: 40));
    }
  }

  _addAnimation(String reaction) {
    liveAnimationList.add(
      Positioned(
          bottom: 100,
          right: 0,
          child: AnimatedSwitcher(
            key: UniqueKey(),
            duration: const Duration(milliseconds: 1000),
            child: LiveReactionAnimation(
              endAnimation: setOverLayFalse,
              reaction: reaction,
            ),
          )),
    );
    update();
  }

  setOverLayFalse() {
    if (liveAnimationList.isNotEmpty) {
      liveAnimationList.removeAt(0);
      if (liveAnimationList.isEmpty) {
        isOverlayOpen = false;
        update();
      }
    }
  }

  composerStateCallBack(CometChatMessageComposerController composerState) {
    composerState = composerState;
  }

  detailsStateCallBack(CometChatDetailsController detailsState) {
    detailsState = detailsState;
  }

  onThreadRepliesClick(BaseMessage message, BuildContext context,
      {Widget Function(BaseMessage, BuildContext)? bubbleView}) async {
    if (loggedInUser != null) {
      // Hide panel before navigation
      updatePanelVisibility(false, 0);

      await Navigator.push(
        context,
        MaterialPageRoute(
            builder: (context) => CometChatThreadedMessages(
                  parentMessage: message,
                  loggedInUser: loggedInUser!,
                  title: threadedMessagesConfiguration?.title,
                  closeIcon: threadedMessagesConfiguration?.closeIcon,
                  bubbleView:
                      threadedMessagesConfiguration?.bubbleView ?? bubbleView,
                  messageActionView:
                      threadedMessagesConfiguration?.messageActionView,
                  messageListConfiguration:
                      threadedMessagesConfiguration?.messageListConfiguration,
                  messageComposerConfiguration: threadedMessagesConfiguration
                      ?.messageComposerConfiguration,
                  threadedMessagesStyle:
                      threadedMessagesConfiguration?.threadedMessagesStyle,
                  hideMessageComposer:
                      threadedMessagesConfiguration?.hideMessageComposer,
                  messageComposerView:
                      threadedMessagesConfiguration?.messageComposerView,
                  messageListView:
                      threadedMessagesConfiguration?.messageListView,
                )),
      );

      // Reset panel state after return
      updatePanelVisibility(false, 0);
    }
  }

  @override
  void showPanel(Map<String, dynamic>? id, CustomUIPosition uiPosition,
      WidgetBuilder child) {
    if (uiPosition == CustomUIPosition.composerBottom) {
      double height = _parsePanelHeight(id?["sticker_height"]);
      updatePanelVisibility(true, height);
    }
  }

  @override
  void hidePanel(Map<String, dynamic>? id, CustomUIPosition uiPosition) {
    if (uiPosition == CustomUIPosition.composerBottom) {
      double height = _parsePanelHeight(id?["sticker_height"]);
      updatePanelVisibility(false, height);
    }
  }

  double _parsePanelHeight(dynamic stickerHeight) {
    try {
      if (stickerHeight is int) return stickerHeight.toDouble();
      if (stickerHeight is double) return stickerHeight;
      if (stickerHeight is String) return double.tryParse(stickerHeight) ?? 0;
      return 0.0;
    } catch (e) {
      debugPrint("Error parsing panel height: $e");
      return 0.0;
    }
  }
}
